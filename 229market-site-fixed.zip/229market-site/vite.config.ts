import { defineConfig } from "vite";
import { tanstackStart } from "@tanstack/react-start/plugin/vite";
import netlify from "@netlify/vite-plugin-tanstack-start";
import viteReact from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import tsConfigPaths from "vite-tsconfig-paths";

export default defineConfig({
  plugins: [
    tsConfigPaths({ projects: ["./tsconfig.json"] }),
    tailwindcss(),
    tanstackStart({
      // Custom SSR entry (see src/server.ts).
      server: { entry: "./src/server.ts" },
    }),
    // Official Netlify adapter for TanStack Start — builds SSR routes, server
    // functions and middleware as Netlify serverless functions.
    netlify(),
    // React's Vite plugin must come after TanStack Start's.
    viteReact(),
  ],
});
