import { Link, useNavigate } from "@tanstack/react-router";
import { LogOut } from "lucide-react";
import { useAuth } from "@/lib/auth";

export function SiteHeader() {
  const { user, profile, signOut } = useAuth();
  const navigate = useNavigate();

  return (
    <header className="flex flex-wrap items-center justify-between gap-3 border-b-2 border-foreground px-6 py-4">
      <Link to="/" className="flex items-center gap-2.5">
        <span className="brand-mark h-9 w-9 font-display text-xs font-black">229</span>
        <span className="font-display text-xl font-black">Market</span>
      </Link>

      <nav className="flex items-center gap-5 text-sm">
        <Link to="/boutique" className="font-medium text-muted-foreground hover:text-foreground">
          Boutiques
        </Link>
        <Link to="/espace" className="font-medium text-muted-foreground hover:text-foreground">
          Mon espace
        </Link>
        {user ? (
          <button
            onClick={async () => {
              await signOut();
              await navigate({ to: "/" });
            }}
            className="flex items-center gap-1.5 rounded-md border-2 border-foreground px-3 py-1.5 font-semibold transition-colors hover:bg-foreground hover:text-background"
          >
            <LogOut size={14} /> {profile?.pseudo ?? "Quitter"}
          </button>
        ) : null}
      </nav>
    </header>
  );
}
