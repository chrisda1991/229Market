import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Users, ShieldCheck, ArrowRight, Search } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { SiteHeader } from "@/components/SiteHeader";
import { rankShops, rankProducts, type SearchableShop, type SearchableProduct } from "@/lib/search";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "229Market — Vendez en ligne au Bénin" },
      {
        name: "description",
        content:
          "Créez votre boutique en ligne en quelques minutes, rejoignez le Marché 229 et discutez avec vos clients.",
      },
      { property: "og:title", content: "229Market — Vendez en ligne au Bénin" },
      {
        property: "og:description",
        content: "Boutiques, Marché 229 et messagerie pour les vendeurs béninois.",
      },
    ],
  }),
  component: Index,
});

// couleurs de fond stables pour les vignettes de boutiques, dérivées de la catégorie + du nom
const SWATCHES = ["#B33B2A", "#1D4E89", "#6E4A2E", "#8A3B6B", "#3F6B4A", "#C1501B"];
function swatchFor(seed: string) {
  let h = 0;
  for (let i = 0; i < seed.length; i++) h = (h * 31 + seed.charCodeAt(i)) >>> 0;
  return SWATCHES[h % SWATCHES.length];
}

function Index() {
  const [query, setQuery] = useState("");

  // On charge un plus grand lot de boutiques (avec leur nombre d'articles réel)
  // pour pouvoir les classer nous-mêmes plutôt que de nous limiter aux 6 dernières.
  const { data: rawShops } = useQuery({
    queryKey: ["shops-home"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("shops")
        .select("id, name, slug, category, created_at, products(count)")
        .order("created_at", { ascending: false })
        .limit(60);
      if (error) throw error;
      return (data ?? []).map((s) => ({
        id: s.id,
        name: s.name,
        slug: s.slug,
        category: s.category,
        created_at: s.created_at,
        productCount: Array.isArray(s.products) ? (s.products[0]?.count ?? 0) : 0,
      })) as SearchableShop[];
    },
  });

  // Recherche d'articles à travers toutes les boutiques, activée seulement
  // quand l'utilisateur tape quelque chose (évite de charger tous les produits en permanence).
  const trimmedQuery = query.trim();
  const { data: rawProducts } = useQuery({
    queryKey: ["product-search", trimmedQuery],
    enabled: trimmedQuery.length >= 2,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("products")
        .select("id, name, price, description, shop:shops(name, slug, category)")
        .ilike("name", `%${trimmedQuery}%`)
        .limit(30);
      if (error) throw error;
      return (data ?? []).filter((p) => p.shop) as unknown as SearchableProduct[];
    },
  });

  const shops = useMemo(() => rankShops(rawShops ?? [], query), [rawShops, query]);
  const matchedProducts = useMemo(
    () => rankProducts(rawProducts ?? [], query),
    [rawProducts, query],
  );

  // catégories réellement présentes parmi les boutiques inscrites (pas de liste figée)
  const categories = Array.from(new Set((rawShops ?? []).map((s) => s.category))).slice(0, 10);

  return (
    <div className="min-h-screen">
      <SiteHeader />

      <section className="border-b-2 border-foreground">
        <div className="mx-auto grid max-w-5xl items-stretch md:grid-cols-[1.15fr_0.85fr]">
          <div className="flex flex-col justify-center gap-6 px-6 py-14 md:py-20">
            <h1 className="font-display text-4xl font-black leading-[0.98] sm:text-5xl">
              Le marché béninois,
              <br />
              maintenant dans
              <br />
              ta poche.
            </h1>
            <p className="max-w-md text-muted-foreground">
              Ouvre ta boutique en ligne en deux minutes. Vends tes articles, tes plats, tes
              créations — les clients t'appellent directement, sans commission.
            </p>
            <div className="flex flex-wrap gap-3">
              <Link
                to="/boutique"
                className="inline-flex items-center gap-2 rounded-md border-2 border-foreground bg-accent px-5 py-3 font-bold text-accent-foreground"
              >
                Ouvrir ma boutique <ArrowRight size={16} />
              </Link>
              <Link
                to="/espace"
                className="inline-flex items-center gap-2 rounded-md border-2 border-foreground px-5 py-3 font-bold hover:bg-foreground hover:text-background"
              >
                Rejoindre le Marché
              </Link>
            </div>
          </div>
          <div className="relative flex items-end border-t-2 border-foreground bg-[var(--marigold)] p-6 md:min-h-[380px] md:border-l-2 md:border-t-0">
            <div className="brand-mark absolute right-6 top-6 h-24 w-24 rotate-6 flex-col font-display text-2xl font-black">
              229
              <span className="mt-0.5 font-sans text-[0.6rem] font-semibold">COTONOU</span>
            </div>
            <div className="panel w-full space-y-2 p-4">
              <p className="font-display text-lg font-semibold">Ma boutique, mes règles</p>
              <p className="text-sm text-muted-foreground">
                Un lien à partager, un numéro pour être appelé. Pas d'abonnement, pas de
                commission sur tes ventes.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="border-b-2 border-foreground px-6 py-5">
        <div className="mx-auto flex max-w-5xl items-center gap-2.5 rounded-md border-2 border-foreground bg-background px-4 py-3">
          <Search size={18} className="shrink-0 text-muted-foreground" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Chercher une boutique, un article, une catégorie…"
            className="w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground"
          />
        </div>
      </section>

      {categories.length > 0 && (
        <section className="border-b-2 border-foreground bg-foreground py-4">
          <div className="mx-auto flex max-w-5xl flex-wrap gap-2 px-6">
            {categories.map((c) => (
              <span
                key={c}
                className="chip"
                style={{ borderColor: "var(--marigold)", color: "var(--marigold)" }}
              >
                {c}
              </span>
            ))}
          </div>
        </section>
      )}

      <main className="mx-auto max-w-5xl px-6 py-16">
        {trimmedQuery.length >= 2 && matchedProducts.length > 0 && (
          <section className="mb-14">
            <h2 className="mb-6 text-2xl font-bold">Articles trouvés</h2>
            <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {matchedProducts.map((p) => (
                <Link
                  key={p.id}
                  to="/boutique/$slug"
                  params={{ slug: p.shop.slug }}
                  className="panel space-y-1.5 p-4"
                >
                  <p className="font-display font-semibold">{p.name}</p>
                  <span className="price-tag">{p.price}</span>
                  <p className="text-xs text-muted-foreground">
                    {p.shop.name} · {p.shop.category}
                  </p>
                </Link>
              ))}
            </div>
          </section>
        )}

        {shops && shops.length > 0 ? (
          <section>
            <div className="mb-6 flex flex-wrap items-baseline justify-between gap-3">
              <h2 className="text-2xl font-bold">
                {trimmedQuery ? "Boutiques correspondantes" : "Boutiques à la une"}
              </h2>
            </div>
            <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {shops.map((s) => (
                <Link key={s.id} to="/boutique/$slug" params={{ slug: s.slug }} className="stall">
                  <div
                    className="flex h-28 items-center justify-center px-3 text-center font-display font-bold"
                    style={{ background: swatchFor(s.category + s.name), color: "var(--cream)" }}
                  >
                    {s.name}
                  </div>
                  <div className="space-y-1 p-4">
                    <p className="text-xs font-semibold" style={{ color: "var(--cobalt)" }}>
                      {s.category}
                    </p>
                    <p className="font-display text-lg font-semibold">{s.name}</p>
                  </div>
                </Link>
              ))}
            </div>
          </section>
        ) : trimmedQuery.length >= 2 && matchedProducts.length === 0 ? (
          <section className="panel p-8 text-center">
            <h2 className="font-display text-xl font-bold">Aucun résultat pour « {trimmedQuery} »</h2>
            <p className="mx-auto mt-2 max-w-sm text-sm text-muted-foreground">
              Essayez un autre mot-clé ou une catégorie plus générale.
            </p>
          </section>
        ) : (
          <section className="panel p-8 text-center">
            <h2 className="font-display text-xl font-bold">Aucune boutique pour le moment</h2>
            <p className="mx-auto mt-2 max-w-sm text-sm text-muted-foreground">
              Soyez le premier ou la première à ouvrir une boutique sur 229Market.
            </p>
            <Link
              to="/boutique"
              className="mt-5 inline-flex items-center gap-2 rounded-md border-2 border-foreground bg-accent px-5 py-2.5 font-bold text-accent-foreground"
            >
              Ouvrir ma boutique <ArrowRight size={16} />
            </Link>
          </section>
        )}

        <section className="mt-20">
          <h2 className="mb-6 text-2xl font-bold">Comment ça marche</h2>
          <div className="grid overflow-hidden rounded-xl border-2 border-foreground sm:grid-cols-3">
            {[
              {
                n: "1",
                t: "Inscris-toi avec ton numéro",
                d: "Pas d'email à créer. Ton numéro de téléphone suffit pour ouvrir ta boutique.",
              },
              {
                n: "2",
                t: "Ajoute tes produits",
                d: "Photo, prix, description. Autant de produits que tu veux, quand tu veux.",
              },
              {
                n: "3",
                t: "Réponds à tes clients",
                d: "Ils t'appellent ou t'écrivent directement. Aucune commission sur tes ventes.",
              },
            ].map((step, i) => (
              <div
                key={step.n}
                className={`p-7 ${i > 0 ? "border-t-2 border-foreground sm:border-l-2 sm:border-t-0" : ""}`}
              >
                <span
                  className="font-display text-3xl font-black"
                  style={{ color: "var(--marigold)", WebkitTextStroke: "1.5px var(--ink)" }}
                >
                  {step.n}
                </span>
                <h3 className="mt-2 font-display text-lg font-semibold">{step.t}</h3>
                <p className="mt-1.5 text-sm text-muted-foreground">{step.d}</p>
              </div>
            ))}
          </div>
        </section>

        <div className="mt-16 flex items-center gap-4">
          <Users size={18} className="text-muted-foreground" />
          <p className="text-sm text-muted-foreground">
            Le Marché 229 rassemble les vendeurs dans un fil commun — accessible depuis{" "}
            <Link to="/espace" className="font-semibold underline underline-offset-4">
              Mon espace
            </Link>
            .
          </p>
        </div>

        <Link
          to="/admin"
          className="mt-14 inline-flex items-center gap-1.5 text-xs text-muted-foreground/70 hover:text-foreground"
        >
          <ShieldCheck size={14} /> Espace administrateur
        </Link>
      </main>
    </div>
  );
}
