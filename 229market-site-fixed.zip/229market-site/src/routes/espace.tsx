import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Clock, MessageCircle, RefreshCw, Send, ShieldCheck, XCircle } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { SiteHeader } from "@/components/SiteHeader";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/espace")({
  head: () => ({
    meta: [
      { title: "Mon espace — 229Market" },
      {
        name: "description",
        content:
          "Rejoignez le Marché 229, publiez vos articles, commentez et discutez en privé avec les autres vendeurs.",
      },
      { property: "og:title", content: "Mon espace — 229Market" },
      {
        property: "og:description",
        content: "Marché 229, commentaires et messagerie privée entre vendeurs.",
      },
    ],
  }),
  component: EspacePage,
});

function EspacePage() {
  const { user, loading } = useAuth();
  return (
    <div className="min-h-screen">
      <SiteHeader />
      <main className="mx-auto max-w-3xl px-6 pb-24 pt-10">
        {loading ? (
          <p className="text-muted-foreground">Chargement…</p>
        ) : user ? (
          <MemberSpace />
        ) : (
          <MemberAuth />
        )}
      </main>
    </div>
  );
}

function MemberAuth() {
  const { signIn, signUp } = useAuth();
  const [mode, setMode] = useState<"register" | "login">("register");
  const [pseudo, setPseudo] = useState("");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    setError("");
    if (!phone.trim() || !password.trim() || (mode === "register" && !pseudo.trim())) {
      setError("Remplissez tous les champs.");
      return;
    }
    setBusy(true);
    try {
      if (mode === "register") await signUp({ pseudo, phone, password });
      else await signIn({ phone, password });
    } catch (e) {
      setError(e instanceof Error ? e.message : "Une erreur est survenue.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="mx-auto max-w-md">
      <div className="mb-5 flex gap-2">
        {(
          [
            { id: "register", label: "M'inscrire" },
            { id: "login", label: "Me connecter" },
          ] as const
        ).map((t) => (
          <button
            key={t.id}
            onClick={() => setMode(t.id)}
            className={`flex-1 rounded-lg px-3 py-2.5 text-sm font-semibold ${
              mode === t.id
                ? "bg-primary text-primary-foreground"
                : "border border-border text-foreground"
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>
      <div className="panel space-y-4 p-6">
        {mode === "register" && (
          <div>
            <label className="text-sm font-semibold">Pseudo</label>
            <input
              className="field mt-1.5"
              value={pseudo}
              onChange={(e) => setPseudo(e.target.value)}
              placeholder="Ex : Rachelle"
            />
          </div>
        )}
        <div>
          <label className="text-sm font-semibold">Téléphone</label>
          <input
            className="field mt-1.5"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            placeholder="01 97 00 00 00"
          />
        </div>
        <div>
          <label className="text-sm font-semibold">Mot de passe</label>
          <input
            type="password"
            className="field mt-1.5"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="6 caractères minimum"
          />
        </div>
        {error && <p className="text-sm font-medium text-accent">{error}</p>}
        <button
          disabled={busy}
          onClick={submit}
          className="w-full rounded-md border-2 border-foreground bg-accent px-4 py-3 font-bold text-accent-foreground disabled:opacity-60"
        >
          {busy ? "Patientez…" : "Continuer"}
        </button>
      </div>
    </div>
  );
}

type Post = {
  id: string;
  author_id: string;
  article: string;
  prix: string;
  created_at: string;
};

function MemberSpace() {
  const { user, profile } = useAuth();
  const qc = useQueryClient();
  const [tab, setTab] = useState<"marche" | "messages">("marche");

  const requestQuery = useQuery({
    queryKey: ["market-request", user?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("market_requests")
        .select("status")
        .eq("user_id", user!.id)
        .maybeSingle();
      if (error) throw error;
      return data;
    },
  });

  const status = requestQuery.data?.status ?? "none";

  const askAccess = async () => {
    const { error } = await supabase
      .from("market_requests")
      .insert({ user_id: user!.id, status: "pending" });
    if (error) {
      toast.error("Demande impossible pour le moment.");
      return;
    }
    toast.success("Demande envoyée à l'administrateur.");
    void qc.invalidateQueries({ queryKey: ["market-request"] });
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Bonjour {profile?.pseudo ?? ""}</h1>
        <p className="text-sm text-muted-foreground">Votre espace membre 229Market</p>
      </div>

      <div className="flex gap-2">
        {(
          [
            { id: "marche", label: "Marché 229" },
            { id: "messages", label: "Messagerie" },
          ] as const
        ).map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`rounded-lg px-4 py-2 text-sm font-semibold ${
              tab === t.id
                ? "bg-primary text-primary-foreground"
                : "border border-border text-foreground"
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {tab === "marche" &&
        (status === "approved" ? (
          <MarketFeed />
        ) : (
          <div className="panel space-y-3 p-6">
            <h2 className="text-xl font-bold">Rejoindre le Marché 229</h2>
            {status === "none" && (
              <>
                <p className="text-sm opacity-80">
                  Demandez votre intégration : l'administrateur validera votre accès.
                </p>
                <button
                  onClick={askAccess}
                  className="rounded-md border-2 border-foreground bg-accent px-4 py-2.5 font-bold text-accent-foreground"
                >
                  Demander l'intégration
                </button>
              </>
            )}
            {status === "pending" && (
              <p className="flex items-center gap-2 text-sm font-semibold">
                <Clock size={16} /> Demande en attente de validation.
              </p>
            )}
            {status === "rejected" && (
              <p className="flex items-center gap-2 text-sm font-semibold text-destructive">
                <XCircle size={16} /> Votre demande a été refusée.
              </p>
            )}
            <button
              onClick={() => void requestQuery.refetch()}
              className="flex items-center gap-1.5 text-sm font-semibold text-accent"
            >
              <RefreshCw size={14} /> Actualiser mon statut
            </button>
          </div>
        ))}

      {tab === "messages" && <Messages />}
    </div>
  );
}

function MarketFeed() {
  const { user } = useAuth();
  const qc = useQueryClient();
  const [draft, setDraft] = useState({ article: "", prix: "" });
  const [commentDrafts, setCommentDrafts] = useState<Record<string, string>>({});

  const feedQuery = useQuery({
    queryKey: ["feed"],
    queryFn: async () => {
      const { data: posts, error } = await supabase
        .from("market_posts")
        .select("id, author_id, article, prix, created_at")
        .order("created_at", { ascending: false })
        .limit(50);
      if (error) throw error;
      const ids = (posts ?? []).map((p) => p.id);
      const { data: comments } = ids.length
        ? await supabase
            .from("market_comments")
            .select("id, post_id, author_id, text, created_at")
            .in("post_id", ids)
            .order("created_at", { ascending: true })
        : { data: [] };
      const authorIds = Array.from(
        new Set([
          ...(posts ?? []).map((p) => p.author_id),
          ...(comments ?? []).map((c) => c.author_id),
        ]),
      );
      const { data: profiles } = authorIds.length
        ? await supabase.from("market_profiles").select("id, pseudo").in("id", authorIds)
        : { data: [] };
      const names = new Map((profiles ?? []).map((p) => [p.id, p.pseudo]));
      return {
        posts: (posts ?? []) as Post[],
        comments: comments ?? [],
        names,
      };
    },
  });

  const publish = async () => {
    if (!draft.article.trim() || !draft.prix.trim()) return;
    const { error } = await supabase
      .from("market_posts")
      .insert({ author_id: user!.id, article: draft.article.trim(), prix: draft.prix.trim() });
    if (error) {
      toast.error("Publication impossible.");
      return;
    }
    setDraft({ article: "", prix: "" });
    void qc.invalidateQueries({ queryKey: ["feed"] });
  };

  const comment = async (postId: string) => {
    const text = (commentDrafts[postId] ?? "").trim();
    if (!text) return;
    const { error } = await supabase
      .from("market_comments")
      .insert({ post_id: postId, author_id: user!.id, text });
    if (error) {
      toast.error("Commentaire impossible.");
      return;
    }
    setCommentDrafts((d) => ({ ...d, [postId]: "" }));
    void qc.invalidateQueries({ queryKey: ["feed"] });
  };

  return (
    <div className="space-y-6">
      <div className="panel space-y-3 p-6">
        <h2 className="text-xl font-bold">Publier un article</h2>
        <div className="grid gap-3 sm:grid-cols-2">
          <input
            className="field"
            placeholder="Article"
            value={draft.article}
            onChange={(e) => setDraft((d) => ({ ...d, article: e.target.value }))}
          />
          <input
            className="field"
            placeholder="Prix"
            value={draft.prix}
            onChange={(e) => setDraft((d) => ({ ...d, prix: e.target.value }))}
          />
        </div>
        <button
          onClick={publish}
          className="rounded-md border-2 border-foreground bg-accent px-4 py-2.5 font-bold text-accent-foreground"
        >
          Publier
        </button>
      </div>

      {feedQuery.data?.posts.map((post) => {
        const postComments = feedQuery.data.comments.filter((c) => c.post_id === post.id);
        return (
          <article key={post.id} className="rounded-md border-2 border-foreground p-5">
            <div className="flex items-baseline justify-between gap-3">
              <h3 className="font-bold">{post.article}</h3>
              <span className="font-semibold text-primary">{post.prix}</span>
            </div>
            <p className="text-xs text-muted-foreground">
              par {feedQuery.data.names.get(post.author_id) ?? "Vendeur"}
            </p>

            <div className="mt-3 space-y-1.5">
              {postComments.map((c) => (
                <p key={c.id} className="text-sm text-muted-foreground">
                  <span className="font-semibold text-foreground">
                    {feedQuery.data.names.get(c.author_id) ?? "Membre"} :
                  </span>{" "}
                  {c.text}
                </p>
              ))}
            </div>

            <div className="mt-3 flex gap-2">
              <input
                className="field"
                placeholder="Écrire un commentaire"
                value={commentDrafts[post.id] ?? ""}
                onChange={(e) =>
                  setCommentDrafts((d) => ({ ...d, [post.id]: e.target.value }))
                }
              />
              <button
                onClick={() => void comment(post.id)}
                className="rounded-md border-2 border-foreground bg-primary px-3 text-primary-foreground"
                aria-label="Envoyer le commentaire"
              >
                <MessageCircle size={16} />
              </button>
            </div>
          </article>
        );
      })}
      {feedQuery.data && feedQuery.data.posts.length === 0 && (
        <p className="text-sm text-muted-foreground">Aucun article publié pour l'instant.</p>
      )}
    </div>
  );
}

function Messages() {
  const { user } = useAuth();
  const qc = useQueryClient();
  const [withUser, setWithUser] = useState<string | null>(null);
  const [draft, setDraft] = useState("");
  const bottomRef = useRef<HTMLDivElement>(null);

  const peopleQuery = useQuery({
    queryKey: ["people"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("market_profiles")
        .select("id, pseudo")
        .neq("id", user!.id)
        .order("created_at", { ascending: false })
        .limit(100);
      if (error) throw error;
      return data ?? [];
    },
  });

  const messagesQuery = useQuery({
    queryKey: ["messages", withUser],
    enabled: !!withUser,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("market_messages")
        .select("id, sender_id, recipient_id, text, created_at")
        .or(`and(sender_id.eq.${user!.id},recipient_id.eq.${withUser}),and(sender_id.eq.${withUser},recipient_id.eq.${user!.id})`)
        .order("created_at", { ascending: true });
      if (error) throw error;
      return data ?? [];
    },
  });

  useEffect(() => {
    if (!user) return;
    const channel = supabase
      .channel("messages-live")
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "market_messages" },
        () => void qc.invalidateQueries({ queryKey: ["messages"] }),
      )
      .subscribe();
    return () => {
      void supabase.removeChannel(channel);
    };
  }, [user, qc]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messagesQuery.data]);

  const send = async () => {
    if (!draft.trim() || !withUser) return;
    const { error } = await supabase
      .from("market_messages")
      .insert({ sender_id: user!.id, recipient_id: withUser, text: draft.trim() });
    if (error) {
      toast.error("Message non envoyé.");
      return;
    }
    setDraft("");
    void qc.invalidateQueries({ queryKey: ["messages"] });
  };

  const peopleName = useMemo(
    () => peopleQuery.data?.find((p) => p.id === withUser)?.pseudo ?? "",
    [peopleQuery.data, withUser],
  );

  return (
    <div className="grid gap-4 md:grid-cols-[220px_1fr]">
      <aside className="space-y-1.5">
        <h2 className="mb-2 text-sm font-bold uppercase tracking-wide text-muted-foreground">
          Membres
        </h2>
        {peopleQuery.data?.map((p) => (
          <button
            key={p.id}
            onClick={() => setWithUser(p.id)}
            className={`w-full rounded-lg px-3 py-2 text-left text-sm ${
              withUser === p.id ? "bg-primary text-primary-foreground" : "border border-border"
            }`}
          >
            {p.pseudo}
          </button>
        ))}
        {peopleQuery.data?.length === 0 && (
          <p className="text-sm text-muted-foreground">Aucun autre membre inscrit.</p>
        )}
      </aside>

      <section className="rounded-md border-2 border-foreground p-4">
        {withUser ? (
          <>
            <h3 className="mb-3 font-bold">Discussion avec {peopleName}</h3>
            <div className="max-h-80 space-y-2 overflow-y-auto pr-1">
              {messagesQuery.data?.map((m) => (
                <div
                  key={m.id}
                  className={`max-w-[80%] rounded-xl px-3 py-2 text-sm ${
                    m.sender_id === user!.id
                      ? "ml-auto bg-primary text-primary-foreground"
                      : "bg-secondary text-secondary-foreground"
                  }`}
                >
                  {m.text}
                </div>
              ))}
              <div ref={bottomRef} />
            </div>
            <div className="mt-3 flex gap-2">
              <input
                className="field"
                placeholder="Votre message"
                value={draft}
                onChange={(e) => setDraft(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") void send();
                }}
              />
              <button
                onClick={() => void send()}
                className="rounded-md border-2 border-foreground bg-accent px-3 text-accent-foreground"
                aria-label="Envoyer"
              >
                <Send size={16} />
              </button>
            </div>
          </>
        ) : (
          <p className="flex items-center gap-2 text-sm text-muted-foreground">
            <ShieldCheck size={16} /> Choisissez un membre pour commencer la discussion.
          </p>
        )}
      </section>
    </div>
  );
}
