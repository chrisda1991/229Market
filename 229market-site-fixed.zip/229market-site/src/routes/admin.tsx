import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { CheckCircle2, KeyRound, ShieldCheck, XCircle } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { SiteHeader } from "@/components/SiteHeader";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/admin")({
  head: () => ({
    meta: [
      { title: "Administration — 229Market" },
      {
        name: "description",
        content: "Validez ou refusez les demandes d'accès au Marché 229.",
      },
      { property: "og:title", content: "Administration — 229Market" },
      { property: "og:description", content: "Gestion des demandes d'accès au Marché 229." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AdminPage,
});

function AdminPage() {
  const { user, loading } = useAuth();
  const qc = useQueryClient();
  const [code, setCode] = useState("");

  const roleQuery = useQuery({
    queryKey: ["is-admin", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("market_user_roles")
        .select("role")
        .eq("user_id", user!.id)
        .eq("role", "admin")
        .maybeSingle();
      if (error) throw error;
      return !!data;
    },
  });

  const requestsQuery = useQuery({
    queryKey: ["admin-requests"],
    enabled: roleQuery.data === true,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("market_requests")
        .select("user_id, status, requested_at")
        .order("requested_at", { ascending: false });
      if (error) throw error;
      const ids = (data ?? []).map((r) => r.user_id);
      const { data: profiles } = ids.length
        ? await supabase.from("market_profiles").select("id, pseudo, phone").in("id", ids)
        : { data: [] };
      const map = new Map((profiles ?? []).map((p) => [p.id, p]));
      return (data ?? []).map((r) => ({ ...r, profile: map.get(r.user_id) }));
    },
  });

  const claim = async () => {
    const { data, error } = await supabase.rpc("market_claim_admin", { _code: code });
    if (error || data !== true) {
      toast.error("Code administrateur incorrect.");
      return;
    }
    toast.success("Accès administrateur activé.");
    void qc.invalidateQueries({ queryKey: ["is-admin"] });
  };

  const decide = async (userId: string, status: "approved" | "rejected") => {
    const { error } = await supabase
      .from("market_requests")
      .update({ status, updated_at: new Date().toISOString() })
      .eq("user_id", userId);
    if (error) {
      toast.error("Action impossible.");
      return;
    }
    void qc.invalidateQueries({ queryKey: ["admin-requests"] });
  };

  return (
    <div className="min-h-screen">
      <SiteHeader />
      <main className="mx-auto max-w-3xl px-6 pb-24 pt-10">
        <h1 className="flex items-center gap-2 text-3xl font-bold">
          <ShieldCheck size={26} className="text-primary" /> Administration
        </h1>

        {loading && <p className="mt-6 text-muted-foreground">Chargement…</p>}

        {!loading && !user && (
          <p className="mt-6 text-muted-foreground">
            Connectez-vous d'abord depuis « Mon espace » pour accéder à l'administration.
          </p>
        )}

        {user && roleQuery.data === false && (
          <div className="panel mt-6 max-w-sm space-y-3 p-6">
            <label className="flex items-center gap-2 text-sm font-semibold">
              <KeyRound size={16} /> Code administrateur
            </label>
            <input
              className="field"
              type="password"
              value={code}
              onChange={(e) => setCode(e.target.value)}
              placeholder="Entrez le code"
            />
            <button
              onClick={claim}
              className="w-full rounded-md border-2 border-foreground bg-accent px-4 py-2.5 font-bold text-accent-foreground"
            >
              Valider
            </button>
          </div>
        )}

        {roleQuery.data === true && (
          <section className="mt-8 space-y-3">
            <h2 className="text-xl font-bold">Demandes d'accès au Marché 229</h2>
            {requestsQuery.data?.map((r) => (
              <div
                key={r.user_id}
                className="flex flex-wrap items-center gap-3 rounded-md border-2 border-foreground p-4"
              >
                <div className="min-w-0 flex-1">
                  <p className="font-semibold">{r.profile?.pseudo ?? "Membre"}</p>
                  <p className="text-xs text-muted-foreground">
                    {r.profile?.phone ?? "—"} · statut : {r.status}
                  </p>
                </div>
                <button
                  onClick={() => void decide(r.user_id, "approved")}
                  className="flex items-center gap-1.5 rounded-md bg-primary px-3 py-1.5 text-sm font-semibold text-primary-foreground"
                >
                  <CheckCircle2 size={14} /> Approuver
                </button>
                <button
                  onClick={() => void decide(r.user_id, "rejected")}
                  className="flex items-center gap-1.5 rounded-md border border-border px-3 py-1.5 text-sm font-semibold"
                >
                  <XCircle size={14} /> Refuser
                </button>
              </div>
            ))}
            {requestsQuery.data?.length === 0 && (
              <p className="text-sm text-muted-foreground">Aucune demande pour le moment.</p>
            )}
          </section>
        )}
      </main>
    </div>
  );
}
