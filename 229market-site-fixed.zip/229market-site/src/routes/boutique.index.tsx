import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Copy, ImagePlus, Plus, Trash2, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { SiteHeader } from "@/components/SiteHeader";
import { useAuth } from "@/lib/auth";
import { resizeImage, slugify } from "@/lib/images";

const CATEGORIES = [
  "Mode & Habillement",
  "Électronique",
  "Beauté & Cosmétique",
  "Alimentation",
  "Maison & Déco",
  "Autre",
];

export const Route = createFileRoute("/boutique/")({
  head: () => ({
    meta: [
      { title: "Ma boutique — 229Market" },
      {
        name: "description",
        content:
          "Créez votre boutique 229Market, publiez vos articles avec photo et prix, et partagez votre lien.",
      },
      { property: "og:title", content: "Ma boutique — 229Market" },
      {
        property: "og:description",
        content: "Créez votre boutique en ligne et partagez votre lien de vente.",
      },
    ],
  }),
  component: BoutiquePage,
});

function BoutiquePage() {
  const { user, loading } = useAuth();

  return (
    <div className="min-h-screen">
      <SiteHeader />
      <main className="mx-auto max-w-3xl px-6 pb-24 pt-10">
        {loading ? (
          <p className="text-muted-foreground">Chargement…</p>
        ) : user ? (
          <ShopDashboard />
        ) : (
          <AuthCard />
        )}
      </main>
    </div>
  );
}

function AuthCard() {
  const { signIn, signUp } = useAuth();
  const [mode, setMode] = useState<"register" | "login">("register");
  const [pseudo, setPseudo] = useState("");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const submit = async () => {
    setError("");
    if (!phone.trim() || !password.trim() || (mode === "register" && !pseudo.trim())) {
      setError("Remplissez tous les champs.");
      return;
    }
    if (password.length < 6) {
      setError("Le mot de passe doit contenir au moins 6 caractères.");
      return;
    }
    setBusy(true);
    try {
      if (mode === "register") {
        await signUp({ pseudo, phone, password });
        toast.success("Compte créé, bienvenue !");
      } else {
        await signIn({ phone, password });
        toast.success("Connexion réussie");
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : "Une erreur est survenue.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="mx-auto max-w-md">
      <div className="mb-5 flex gap-2">
        {(
          [
            { id: "register", label: "Créer mon compte" },
            { id: "login", label: "J'ai déjà un compte" },
          ] as const
        ).map((t) => (
          <button
            key={t.id}
            onClick={() => {
              setMode(t.id);
              setError("");
            }}
            className={`flex-1 rounded-md border-2 border-foreground px-3 py-2.5 text-sm font-semibold ${
              mode === t.id ? "bg-accent text-accent-foreground" : "text-foreground"
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      <div className="panel space-y-4 p-6">
        {mode === "register" && (
          <div>
            <label className="text-sm font-semibold">Votre nom ou pseudo</label>
            <input
              className="field mt-1.5"
              value={pseudo}
              onChange={(e) => setPseudo(e.target.value)}
              placeholder="Ex : Rachelle"
            />
          </div>
        )}
        <div>
          <label className="text-sm font-semibold">Numéro de téléphone</label>
          <input
            className="field mt-1.5"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            placeholder="Ex : 01 97 00 00 00"
          />
        </div>
        <div>
          <label className="text-sm font-semibold">Mot de passe</label>
          <input
            type="password"
            className="field mt-1.5"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="6 caractères minimum"
          />
        </div>
        {error && <p className="text-sm font-medium text-accent">{error}</p>}
        <button
          disabled={busy}
          onClick={submit}
          className="w-full rounded-md border-2 border-foreground bg-accent px-4 py-3 font-bold text-accent-foreground disabled:opacity-60"
        >
          {busy ? "Patientez…" : mode === "register" ? "Créer mon compte" : "Me connecter"}
        </button>
      </div>
    </div>
  );
}

function ShopDashboard() {
  const { user, profile } = useAuth();
  const qc = useQueryClient();
  const [creating, setCreating] = useState({ name: "", category: "Mode & Habillement" });
  const [newProduct, setNewProduct] = useState({
    name: "",
    price: "",
    description: "",
    photo: "",
  });
  const [busy, setBusy] = useState(false);
  const [copied, setCopied] = useState(false);

  const shopQuery = useQuery({
    queryKey: ["my-shop", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("shops")
        .select("id, name, slug, category, phone")
        .eq("owner_id", user!.id)
        .maybeSingle();
      if (error) throw error;
      return data;
    },
  });

  const shop = shopQuery.data;

  const productsQuery = useQuery({
    queryKey: ["my-products", shop?.id],
    enabled: !!shop,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("products")
        .select("id, name, price, description, photo_url")
        .eq("shop_id", shop!.id)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
  });

  const createShop = async () => {
    if (!creating.name.trim()) return;
    setBusy(true);
    let slug = slugify(creating.name);
    const { data: taken } = await supabase.from("shops").select("id").eq("slug", slug).maybeSingle();
    if (taken) slug = `${slug}-${Math.floor(Math.random() * 9000 + 1000)}`;
    const { error } = await supabase.from("shops").insert({
      owner_id: user!.id,
      name: creating.name.trim(),
      slug,
      category: creating.category,
      phone: profile?.phone ?? null,
    });
    setBusy(false);
    if (error) {
      toast.error("La boutique n'a pas pu être créée.");
      return;
    }
    toast.success("Boutique créée !");
    void qc.invalidateQueries({ queryKey: ["my-shop"] });
  };

  const addProduct = async () => {
    if (!newProduct.name.trim() || !newProduct.price.trim()) {
      toast.error("Le nom et le prix sont obligatoires.");
      return;
    }
    setBusy(true);
    const { error } = await supabase.from("products").insert({
      shop_id: shop!.id,
      name: newProduct.name.trim(),
      price: newProduct.price.trim(),
      description: newProduct.description.trim() || null,
      photo_url: newProduct.photo || null,
    });
    setBusy(false);
    if (error) {
      toast.error("Publication impossible.");
      return;
    }
    setNewProduct({ name: "", price: "", description: "", photo: "" });
    void qc.invalidateQueries({ queryKey: ["my-products"] });
  };

  const removeProduct = async (id: string) => {
    const { error } = await supabase.from("products").delete().eq("id", id);
    if (error) {
      toast.error("Suppression impossible.");
      return;
    }
    void qc.invalidateQueries({ queryKey: ["my-products"] });
  };

  const onPhoto = async (file?: File) => {
    if (!file) return;
    try {
      const dataUrl = await resizeImage(file);
      setNewProduct((p) => ({ ...p, photo: dataUrl }));
    } catch {
      toast.error("Impossible de lire cette image.");
    }
  };

  if (shopQuery.isLoading) return <p className="text-muted-foreground">Chargement…</p>;

  if (!shop) {
    return (
      <div className="mx-auto max-w-md panel space-y-4 p-6">
        <h1 className="text-2xl font-bold">Créer ma boutique</h1>
        <div>
          <label className="text-sm font-semibold">Nom de la boutique</label>
          <input
            className="field mt-1.5"
            value={creating.name}
            onChange={(e) => setCreating((c) => ({ ...c, name: e.target.value }))}
            placeholder="Ex : Chez Rachelle Mode"
          />
        </div>
        <div>
          <label className="text-sm font-semibold">Catégorie</label>
          <select
            className="field mt-1.5"
            value={creating.category}
            onChange={(e) => setCreating((c) => ({ ...c, category: e.target.value }))}
          >
            {CATEGORIES.map((c) => (
              <option key={c}>{c}</option>
            ))}
          </select>
        </div>
        <button
          disabled={busy}
          onClick={createShop}
          className="w-full rounded-md border-2 border-foreground bg-accent px-4 py-3 font-bold text-accent-foreground disabled:opacity-60"
        >
          {busy ? "Création…" : "Créer ma boutique"}
        </button>
      </div>
    );
  }

  const shopLink =
    typeof window !== "undefined" ? `${window.location.origin}/boutique/${shop.slug}` : "";

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold">{shop.name}</h1>
        <p className="text-sm text-muted-foreground">{shop.category}</p>
        <div className="mt-4 flex flex-wrap items-center gap-2 rounded-md border-2 border-foreground p-3 text-sm">
          <span className="truncate text-muted-foreground">{shopLink}</span>
          <button
            onClick={async () => {
              await navigator.clipboard.writeText(shopLink);
              setCopied(true);
              setTimeout(() => setCopied(false), 2000);
            }}
            className="ml-auto flex items-center gap-1.5 rounded-md bg-primary px-3 py-1.5 font-semibold text-primary-foreground"
          >
            {copied ? <CheckCircle2 size={14} /> : <Copy size={14} />}
            {copied ? "Copié" : "Copier le lien"}
          </button>
          <Link
            to="/boutique/$slug"
            params={{ slug: shop.slug }}
            className="rounded-md border border-border px-3 py-1.5 font-semibold"
          >
            Voir
          </Link>
        </div>
      </div>

      <section className="panel space-y-4 p-6">
        <h2 className="text-xl font-bold">Ajouter un article</h2>
        <div className="grid gap-3 sm:grid-cols-2">
          <input
            className="field"
            placeholder="Nom de l'article"
            value={newProduct.name}
            onChange={(e) => setNewProduct((p) => ({ ...p, name: e.target.value }))}
          />
          <input
            className="field"
            placeholder="Prix (ex : 15 000 FCFA)"
            value={newProduct.price}
            onChange={(e) => setNewProduct((p) => ({ ...p, price: e.target.value }))}
          />
        </div>
        <textarea
          className="field"
          rows={3}
          placeholder="Description (facultatif)"
          value={newProduct.description}
          onChange={(e) => setNewProduct((p) => ({ ...p, description: e.target.value }))}
        />
        <div className="flex flex-wrap items-center gap-3">
          <label className="flex cursor-pointer items-center gap-2 rounded-lg border border-card-foreground/20 px-3 py-2 text-sm font-semibold">
            <ImagePlus size={16} /> Ajouter une photo
            <input
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => void onPhoto(e.target.files?.[0])}
            />
          </label>
          {newProduct.photo && (
            <img src={newProduct.photo} alt="Aperçu" className="h-14 w-14 rounded-md object-cover" />
          )}
          <button
            disabled={busy}
            onClick={addProduct}
            className="ml-auto flex items-center gap-1.5 rounded-md border-2 border-foreground bg-accent px-4 py-2.5 font-bold text-accent-foreground disabled:opacity-60"
          >
            <Plus size={16} /> Publier
          </button>
        </div>
      </section>

      <section className="space-y-3">
        <h2 className="text-xl font-bold">Mes articles</h2>
        {productsQuery.data?.length ? (
          productsQuery.data.map((p) => (
            <div
              key={p.id}
              className="flex items-center gap-4 rounded-md border-2 border-foreground p-3"
            >
              {p.photo_url ? (
                <img src={p.photo_url} alt={p.name} className="h-16 w-16 rounded-md object-cover" />
              ) : (
                <div className="h-16 w-16 rounded-md bg-secondary" />
              )}
              <div className="min-w-0 flex-1">
                <p className="font-semibold">{p.name}</p>
                <p className="text-sm text-primary">{p.price}</p>
                {p.description && (
                  <p className="truncate text-xs text-muted-foreground">{p.description}</p>
                )}
              </div>
              <button
                onClick={() => void removeProduct(p.id)}
                className="rounded-md p-2 text-muted-foreground hover:text-destructive"
                aria-label="Supprimer"
              >
                <Trash2 size={16} />
              </button>
            </div>
          ))
        ) : (
          <p className="text-sm text-muted-foreground">Aucun article publié pour le moment.</p>
        )}
      </section>
    </div>
  );
}
