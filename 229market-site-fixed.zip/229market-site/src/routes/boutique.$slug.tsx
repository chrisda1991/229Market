import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Phone } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { SiteHeader } from "@/components/SiteHeader";

type ShopProduct = {
  id: string;
  name: string;
  price: string;
  description: string | null;
  photo_url: string | null;
};

export const Route = createFileRoute("/boutique/$slug")({
  head: ({ params }) => ({
    meta: [
      { title: `Boutique ${params.slug} — 229Market` },
      {
        name: "description",
        content: `Découvrez les articles et les prix de la boutique ${params.slug} sur 229Market.`,
      },
      { property: "og:title", content: `Boutique ${params.slug} — 229Market` },
      {
        property: "og:description",
        content: `Articles, prix et contact de la boutique ${params.slug}.`,
      },
    ],
  }),
  component: ShopPage,
});

function ShopPage() {
  const { slug } = Route.useParams();

  const { data, isLoading } = useQuery({
    queryKey: ["shop", slug],
    retry: false,
    queryFn: async () => {
      const { data: shop, error } = await supabase
        .from("shops")
        .select("id, name, category, phone")
        .eq("slug", slug)
        .maybeSingle();
      if (error) throw error;
      if (!shop) return { shop: null, products: [] as ShopProduct[] };
      const { data: products } = await supabase
        .from("products")
        .select("id, name, price, description, photo_url")
        .eq("shop_id", shop.id)
        .order("created_at", { ascending: false });
      return { shop, products: products ?? [] };
    },
  });

  return (
    <div className="min-h-screen">
      <SiteHeader />
      <main className="mx-auto max-w-4xl px-6 pb-24 pt-10">
        {isLoading && <p className="text-muted-foreground">Chargement…</p>}
        {!isLoading && !data?.shop && (
          <p className="text-muted-foreground">Boutique introuvable.</p>
        )}
        {data?.shop && (
          <>
            <div className="border-b-2 border-foreground pb-6">
              <p className="text-xs font-semibold" style={{ color: "var(--cobalt)" }}>
                {data.shop.category}
              </p>
              <h1 className="mt-1 font-display text-3xl font-black">{data.shop.name}</h1>
              {data.shop.phone && (
                <a
                  href={`tel:${data.shop.phone}`}
                  className="mt-4 inline-flex items-center gap-2 rounded-md border-2 border-foreground bg-accent px-4 py-2 font-bold text-accent-foreground"
                >
                  <Phone size={16} /> Appeler {data.shop.phone}
                </a>
              )}
            </div>

            <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {data.products.map((p) => (
                <article key={p.id} className="panel overflow-hidden">
                  {p.photo_url ? (
                    <img
                      src={p.photo_url}
                      alt={p.name}
                      className="h-44 w-full border-b-2 border-foreground object-cover"
                    />
                  ) : (
                    <div className="flex h-44 w-full items-center justify-center border-b-2 border-foreground bg-[var(--cream-2)] text-sm text-muted-foreground">
                      Pas de photo
                    </div>
                  )}
                  <div className="space-y-2 p-4">
                    <h2 className="font-display font-semibold">{p.name}</h2>
                    <span className="price-tag">{p.price}</span>
                    {p.description && (
                      <p className="text-sm text-muted-foreground">{p.description}</p>
                    )}
                  </div>
                </article>
              ))}
            </div>
            {data.products.length === 0 && (
              <p className="mt-8 text-muted-foreground">
                Cette boutique n'a pas encore publié d'article.
              </p>
            )}
          </>
        )}
      </main>
    </div>
  );
}
