/**
 * Moteur de classement du marché.
 *
 * Combine trois signaux réels (pas de données factices) :
 *  - pertinence texte vis-à-vis de la recherche de l'utilisateur
 *  - fraîcheur (les boutiques/articles récents remontent)
 *  - popularité (nombre d'articles publiés par la boutique)
 *
 * Le score est recalculé côté client à partir des données Supabase déjà
 * chargées — aucune dépendance externe, aucun appel supplémentaire.
 */

export type SearchableShop = {
  id: string;
  name: string;
  slug: string;
  category: string;
  created_at: string;
  productCount: number;
};

export type SearchableProduct = {
  id: string;
  name: string;
  price: string;
  description: string | null;
  shop: { name: string; slug: string; category: string };
};

/** Normalise une chaîne pour une comparaison insensible aux accents/majuscules. */
function normalize(s: string): string {
  return s
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .trim();
}

function tokenize(s: string): string[] {
  return normalize(s)
    .split(/[^a-z0-9]+/)
    .filter(Boolean);
}

/**
 * Score de correspondance texte entre une requête et un champ.
 * 0 = aucune correspondance, jusqu'à ~1 = correspondance exacte.
 */
function fieldMatchScore(query: string, field: string): number {
  if (!query) return 0;
  const nq = normalize(query);
  const nf = normalize(field);
  if (!nf) return 0;
  if (nf === nq) return 1;
  if (nf.startsWith(nq)) return 0.75;
  if (nf.includes(nq)) return 0.5;

  // correspondance par mots (utile pour "sac cuir" -> "beau sac en cuir marron")
  const qTokens = tokenize(query);
  const fTokens = new Set(tokenize(field));
  if (qTokens.length === 0) return 0;
  const hits = qTokens.filter((t) => fTokens.has(t)).length;
  return hits > 0 ? (0.35 * hits) / qTokens.length : 0;
}

/** Bonus de fraîcheur : décroît linéairement sur 60 jours, plafonné à 0. */
function recencyScore(createdAt: string): number {
  const days = (Date.now() - new Date(createdAt).getTime()) / 86_400_000;
  return Math.max(0, 1 - days / 60);
}

export function rankShops(shops: SearchableShop[], query: string) {
  const q = query.trim();
  return shops
    .map((s) => {
      const textScore = Math.max(
        fieldMatchScore(q, s.name) * 1,
        fieldMatchScore(q, s.category) * 0.6,
      );
      const popularity = Math.min(s.productCount, 20) / 20; // plafonné pour éviter qu'une grosse boutique écrase tout
      const fresh = recencyScore(s.created_at);
      // sans recherche : classement par popularité + fraîcheur.
      // avec recherche : la pertinence texte domine largement.
      const score = q
        ? textScore * 10 + popularity * 1.5 + fresh * 0.5
        : popularity * 3 + fresh * 2;
      return { shop: s, score, matched: q ? textScore > 0 : true };
    })
    .filter((r) => r.matched)
    .sort((a, b) => b.score - a.score)
    .map((r) => r.shop);
}

export function rankProducts(products: SearchableProduct[], query: string) {
  const q = query.trim();
  if (!q) return [];
  return products
    .map((p) => {
      const textScore = Math.max(
        fieldMatchScore(q, p.name) * 1,
        fieldMatchScore(q, p.description ?? "") * 0.5,
        fieldMatchScore(q, p.shop.category) * 0.3,
      );
      return { product: p, score: textScore };
    })
    .filter((r) => r.score > 0)
    .sort((a, b) => b.score - a.score)
    .map((r) => r.product);
}
