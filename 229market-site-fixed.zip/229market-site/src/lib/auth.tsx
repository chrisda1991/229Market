import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import type { Session, User } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";

export type Profile = { id: string; pseudo: string; phone: string | null };

type AuthContextValue = {
  user: User | null;
  session: Session | null;
  profile: Profile | null;
  loading: boolean;
  signUp: (args: { pseudo: string; phone: string; password: string }) => Promise<void>;
  signIn: (args: { phone: string; password: string }) => Promise<void>;
  signOut: () => Promise<void>;
  refreshProfile: () => Promise<void>;
};

const AuthContext = createContext<AuthContextValue | null>(null);

/**
 * Le téléphone sert d'identifiant : on le transforme en identifiant interne stable.
 * On normalise l'indicatif (+229 / 229) et le 0 initial pour qu'un même numéro tapé
 * sous des formes différentes (ex : "+229 01 97 00 00 00" ou "01 97 00 00 00")
 * pointe toujours vers le même compte.
 */
export function phoneToEmail(phone: string) {
  let digits = phone.replace(/\D/g, "");
  if (digits.startsWith("229") && digits.length > 8) digits = digits.slice(3);
  if (digits.startsWith("0")) digits = digits.slice(1);
  return `${digits}@229market.bj`;
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);

  const loadProfile = async (userId: string) => {
    const { data } = await supabase
      .from("market_profiles")
      .select("id, pseudo, phone")
      .eq("id", userId)
      .maybeSingle();
    setProfile((data as Profile) ?? null);
  };

  useEffect(() => {
    const { data: sub } = supabase.auth.onAuthStateChange((_event, newSession) => {
      setSession(newSession);
      setLoading(false);
      if (newSession?.user) {
        setTimeout(() => void loadProfile(newSession.user.id), 0);
      } else {
        setProfile(null);
      }
    });

    void supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      setLoading(false);
      if (data.session?.user) void loadProfile(data.session.user.id);
    });

    return () => sub.subscription.unsubscribe();
  }, []);

  const signUp: AuthContextValue["signUp"] = async ({ pseudo, phone, password }) => {
    const { error } = await supabase.auth.signUp({
      email: phoneToEmail(phone),
      password,
      options: {
        emailRedirectTo: `${window.location.origin}/`,
        data: { pseudo: pseudo.trim(), phone: phone.trim() },
      },
    });
    if (error) {
      if (error.message.toLowerCase().includes("already")) {
        throw new Error("Ce numéro possède déjà un compte. Connectez-vous plutôt.");
      }
      throw new Error(error.message);
    }
  };

  const signIn: AuthContextValue["signIn"] = async ({ phone, password }) => {
    const { error } = await supabase.auth.signInWithPassword({
      email: phoneToEmail(phone),
      password,
    });
    if (error) {
      if (error.message.toLowerCase().includes("not confirmed")) {
        throw new Error(
          "Compte non confirmé. Contactez l'administrateur (configuration : désactiver la confirmation par email dans Supabase).",
        );
      }
      throw new Error("Téléphone ou mot de passe incorrect.");
    }
  };

  const signOut = async () => {
    await supabase.auth.signOut();
    setProfile(null);
  };

  const refreshProfile = async () => {
    if (session?.user) await loadProfile(session.user.id);
  };

  return (
    <AuthContext.Provider
      value={{
        user: session?.user ?? null,
        session,
        profile,
        loading,
        signUp,
        signIn,
        signOut,
        refreshProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth doit être utilisé dans AuthProvider");
  return ctx;
}
