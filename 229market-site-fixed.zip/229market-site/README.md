# 229Market

Marketplace en ligne pour les vendeurs béninois : boutiques, produits, marché
communautaire ("Le Marché") et messagerie entre membres.

## Stack technique

- [TanStack Start](https://tanstack.com/start) (React, SSR)
- TypeScript
- Tailwind CSS
- [Supabase](https://supabase.com) (base de données, authentification, temps réel)
- Déployé sur [Netlify](https://www.netlify.com)

## Développement local

Prérequis : Node.js et Bun.

```sh
git clone <url-du-dépôt>
cd 229market-site
bun install
bun run dev
```

Copiez `.env.example` vers `.env` et renseignez vos propres identifiants
Supabase (`VITE_SUPABASE_URL`, `VITE_SUPABASE_PUBLISHABLE_KEY`,
`VITE_SUPABASE_PROJECT_ID`).

## Build & déploiement

```sh
bun run build
```

Le build est configuré pour le preset Netlify (voir `vite.config.ts` et
`netlify.toml`). Le dossier de publication est `dist`.

## Base de données

Le schéma SQL (tables, RLS, fonctions) se trouve dans `supabase/migrations/`.
