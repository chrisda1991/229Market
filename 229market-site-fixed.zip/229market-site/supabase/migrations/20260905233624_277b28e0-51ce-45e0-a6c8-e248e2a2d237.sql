
REVOKE ALL ON FUNCTION public.has_role(uuid, public.app_role) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.is_market_member(uuid) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.claim_admin(text) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.handle_new_user() FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) TO authenticated;
GRANT EXECUTE ON FUNCTION public.is_market_member(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.claim_admin(text) TO authenticated;
